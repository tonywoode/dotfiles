( Note: I no longer have a Mac so I will not be maintaining this any further. )

# Vimini.app & Vimini.workflow

---

Compatible with iTerm 2.9+ Applescript API.

100% Settings-Free.  There are no settings.  No more settings.  Anymore.

Used to open files from finder inside vim in an iTerm terminal. Opens a session of the default profile, in a new window, labeled more or less uniquely after the file and it's parent folder.  If you try to open the same file, it just goes there.


---
## Vimini.app

For using like droplet – drag files onto the icon for Vimini.app.  Also may be used to form a file-association to open certain type on double-click in finder.

###### The app and the workflow do not depend upon one another.  You may choose to ignore it if you only want the right-click menu offered by the workflow.

---

## Vimini.workflow

As a service – on the right-click menu for files in the Finder.

###### Install the workflow by double clicking it.

---
